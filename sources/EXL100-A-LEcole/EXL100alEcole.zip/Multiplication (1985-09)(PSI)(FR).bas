100 !******** MULTIPLICATION **********
110 !******** VERSION EXL 100 *********
120 !***** D.NIELSEN - 1985 ***********
130 !**********************************
140 ON BREAK ERROR
150 ON ERROR 10000

160 CLS " BC C " : CALL HROFF : CALL INIT : CALL COLOR( " OBC" ) : DI M A$ ( 6 )
170 NO=O : FOR I = 1 TO 6 : READ A$ C l ) :NEXT : Z 2$= "MULT I PL I CATI ON "
175 DATA unites,dizaines,centaines,milliers
176 DATA dizaines de milliers,centaines de milliers
180 CALL DBLPRT ( Z 2$ , " 0 b " , 6 , 1 2 )
190 LOCATE ( 1 5 , 5 ) : PR I NT " Qu e l est t on prenom ?" ;
200 ACCEPT BEEP VAL I DAT E C ALPHA )NULL( " EXEL" ) ,N$
210 PRINT : PRINT " Mu l t i p l i c at i ons par un nombre a UN , DEUX " ; " ou TRO I S c h i f f r e s ? "
220 CAL L COLOR( " O R " ) : PR I NT " I n d i q ue ton ch o i x ( 1 , 2 ou3 ) : I l ;
230 ACCEPT BEEP VAL I DAT E C " 1 23" )NULL< 1 ) S 1 2 E ( 1 ) , CH
240 RANDOM I Z E L EN ( N$ ) *7
250 ! *** C H O I X DES CH I FFRES
260 CALL HRON( " C " , 1 8 , 1 ) : CALL INIT : CLS
270 AC,BC,AD,BD,AU,BU=0:ON CH GOTO 300,290,280
280 BC= I NTRN D ( 9 )
290 BD= I NT RND ( 9 )
300 BU= I NT RND C 9 )
305 AU= I NT RN D ( 9 ) : AD= I NTRND C 9 ) :AC=INTRNDC 9 )
310 ! *** A F F I CHAGE D E L / OPERAT I ON
320 A= 1 0 0 *AC+ 1 0 *AD+AU
330 B= 1 0 0 *BC+ 1 0 *B D + B U
340 CAL L CLR
350 CAL L DBLPRT < ST R$ C A ) , " O B " , 1 8 , 2 ) : CALL DBLPRT< " x "&STRS C B ) , " O B " , 20 - 2*CH , 4 )
360 CALL DBLPRT C RPT$ ( CHR$ ( 4 ) , 2+ CH) , " O B" , 20-CH*2 , 6)
370 LOCAT E ( 1 9 , 1 )
390 I F C H= ! THEN 4 0 1
400 PR I NT " T u v a s c omme n c e r p ar mu l t i' p l i e r " ;A : PRINT " p
ar " ; B U ; " u n i t e s . " : PAUSE 5
40 1 X=2 2 : Y= 8 : N 1 =A U : N2=BU
402 T$=A$ ( 2 ) : VS=A$ ( 1 ) : GOSUB 4000
403 STA=S : X= 2 0 : N 1 =A D
4 0 4 T$=A$ ( 3 ) : V$=A$ ( 2 ) : GOSUB 4000
405 ST B= S : X= 1 8 : N 1 =A C
5 1 0 T$=A$ ( 4 ) : V$=A$ ( 3 ) : G OSUB 4000
530 ST C= S : ST D= RET
540 I F RET O O T H EN CA LL DBLPRT < STR$ ( RET ) , " O R " ,X-2 , Y )
542 I F C H= ! T H EN 560 0
545 LOCAT E ( 1 , 1 ) : P R I NT R PTS < " " , 40 )

550 CLS : LOCATE (19,1) : P RINT "Tu vas ma intenant mu l tipl
ier• ;A , , upar " ;BD;A$ (2)
560 RET= O
570 PA USE 5:X=20 :Y=1 0 :N 1=AU : N2=BD
620 T$=A$(3) :V$=A $(2) :GOSUB 400ü
640 STE=S :X=1 8:N 1=AD
700 T$=A$(4) :V$=A$( 3) :GOSUB 4000
730 ST F= S :X=1 6:N1=AC
810 T$=A$(5) :V$=A $(4) :GOSUB 4000
830 ST G=S : ST H=RET
840 IF RET<>O THEN CA LL DBLPRT(STR$(RET) , "OR" ,X-2 ,Y)
845 LOCATE ( 1, 1) : PRINT RPT$ ( " ", 40 >
850 RET= O
860 IF CH=2 THEN 50 00
870 CLS : LOCAT E (19,1) : P RINT "Tu vas ma intenan t mu l tipl
ier" ;A , ,"p ar " ;BC ;A$( 3)
880 PA USE 5:X= 1 8:Y=1 2:N i=AU : N2=BC
920 T$=A$ (4) :V$=A$( 3) :GOSUB 40 00
940 ST I=S :X=1 6:N 1=AD
1010 T$=A$(5) :V$=A $( 4) :GOSUB 4000
1030 STJ=S :X=1 4:N 1=AC
1110 T$=A$(6) :V$=A$ (5) :GOSUB 4000
1120 IF RET<>O THEN CA LL DBLPRT(STR$(RET) , "OR" ,X-2 ,Y)
1130 STK=S : ST L=RET
1137 LOCATE (1 ,1) :PR INT RPT$( " ",40 )
1140 GOTO 50 00
3000 ! *** TABLE DE MULTIPLICATION
3010 CLS : LOCAT E (19 ,1) : CALL COLOR( " ORB" ):P RINT "Tu te trompes," ;N$;11,11
3015 CALL COLOR ( " 0 B C" ) : PRINT : PRINT " Re 1 i s 1 a t ab 1 e de mu 1 t i p 1 i c a t ion . "
3020 PAUSE 7:CLS : LOCATE (19,1)
3040 FOR I=1 TO 10
3050 K= INT< <I-1 )/3) : LOCATE (K+19,12* <I- 1-3 * K) +1 )
3060 PRINT I ; " x " ; N 2 ; 11 = 11 ; I *N 2 ; " , 11 ; 3070 PA USE 1:N EXT
3080 PAUSE 2:RETURN
4000 ! *** OPERATION PAR UNITES
4005 CLS : LOCATE (19 ,1) : CALL COLOR( "OBC")
4010 PRINT " ,. ,·. 1;., .:: •• : t I l : N 1 : Il X Il j N 2 j I l ? ":
4020 ACCEPT BEEP VALIDATE <DIGIT)NULLCO) ,Rl
4030 IF R1 <>N1 *N2 THEN GOSUB 3000 : GOTO 4000
4100 IF RET<>O THEN GOSUB 4500
4110 IF R1 (10 THEN CA LL DBLPRT< ST R$ ( R1 ),"0b" ,X ,Y) :S=R1 :GOTO 4200
4115 RET= INT< R1/ 10) :S=R 1-( 10* RET )
4120 CLS : PRINT "Cela fait" ;RET;T$;" plus" ;S ;,)$
4130 pRINT " Il faut donc ecrire " ; S ; " dans la colonne "
4135 PRINT "des ";V$ ;" et ajouter " ;RET

4140 PR I NT " a l a mu l t i p l i c at i on des n ;T$ : PAUSE 5
4150 CALL DBLPRT ( STR$ ( S ) , " O b11 ,X ,Y) : LOCATE ( 1 ,X-1 ) : PRINTRET
4200 PAUSE 8 : RETURN
4500 ! *** RETENUE
4505 CLS : LOCATE ( 1 9 , 1 ) : PRINT " I l fau t ma i n tenan t aj ou t er l a r e t e n u e de 11
4506 PR I NT 11 l a m u l t i p l i c a t i on preceden te u
4510 PRI NT u Q u e f a i t " ; R l ; " + " ; RET ; 11 ?• ;
4520 ACCEPT BEEP NULL< O )VAL I DATE ( D I GIT) , R2
4530 IF R2=R1+RET THEN 4600
4540 CALL COLOR("ORB ") : PRINT "Tu te tromp es , " ;N$ ; " , " : CALL COLOR ( 11 0 B C 11) 4550 P R I NT " Re c omme n c e , 11 : PAUSE 3 : GOTO 450 0
4600 .R 1 =R2 : RET=0 : RETURN
5000 !*** ADDITION
5005 CALL DBLPRT ( RPT$ ( CHR$ ( 4 ) , 3+CH) , " O B" , 1 8-CH*2 , 1 4 )
5010 LOCATE ( 1 9 , 1 ) : CLS : PR INT " Il faut maintenant additionner les " ; CH
5020 PRINT " m u 1 t i p 1 i c a t i o n s , "
5030 PRINT " D ✓ abor d , l e s " ; A$ ( 1 ) ; ", " ; " Comb i en ce l a f a i ti1 ? ";
5040 ACCEPT BEEP VAL I DAT E< D I G I T )NULL ( O ) ,TA
5050 I F TA < > STA THEN GOSUB 5700 : GOTO 5030
5100 CALL DBLPRT ( ST R$ ( TA ) , 11 O B " , 22 , 1 6 )
5110 CLS : LOCATE ( 1 9 , 1 ) : PR I NT " En su i t e l e s " ; A$ ( 2)
5120 PR I NT STB ; " + 11 ; STE ; "= ? " ;
5130 ACCEPT BEEP VAL I DATE < D I G IT ) NULL( O ) ,TB
5140 􀜌 F T B < > STE+ ST B THEN GOSUB 5700 : GOTO 5 1 20
5200 CALL DBLPRT ( STR$ (T 8- 1 0 * INT <TB/ 1 0 ) ) 111 0B 11 , 20 , 1 6)
5210 CLS : LOCATE ( 1 9 , 1 ) : PR I NT II Ens u i t e 1 e s 11; A$ < 3)
5220 PRINT STC ; 11 + 11 ; STF ; 11 + 11 ; ST I ; 11 + 11 ; INT <TB/ 1 0 ) ; 11 ( de r e t en u e ) = ? 11;
5230 ACCEPT BEEP VAL I DATE ( D I G IT )NULL ( O ) ,TC
5240 IF TC < > ST C + STF+ ST I + I NT (TB/ 1 0 )THEN GOSUB 5700 : GOTO 5220
5300 CALL DBLPRT ( STR$ < T C- 1 0 * I NT(TC/ 1 0 ) ) , 11 08 11 , 1 8 , 1 6 )
5310 CLS : LOCATE < 1 9 , 1 ) : PR I NT II En su i t e 1 e s 11 ; A$ < 4 )
5320 PRINT STD ; 11 + 11 ; ST G ; 11 + 11 ; STJ ; 11 + 11 ; 1 NT <TC/ 1 0 ) ; 11 ( de e t en u e ) = ? 11 ; 5330 ACCEPT BEEP VAL I DATE ( DI G I T )NULL ( O ) ,TD
5340 I F T D < > ST D + STG+ STJ+ I NT ( TC/ 1 0 )THEN GOSUB 5700 : GOTO 5320
5400 CALL DBLPRT < ST R$<TD-1 0 * INT<TD/1 0)) ,"OB" ,16,16)
5405 IF CH<>2 OR ST H <>O THEN 5410
5406 IF TD/ 1 0 )= 1 T HEN CALL DBLPRT( STR$ ( 1NT ( TD/ 1 0 ) ) , 11 08 11, 1 4 , 1 6 )
5407 GOTO 5 6 0 0
5410 CLS : LOCAT E ( 1 9 , 1 ) : PR I NT " Ensu i t e l e s " ; A$ ( 5)

5420 PRINT STH ; " + n ; STK ; u + " ; INT <TD/ 1 Q ) ; " ( de r e t e n u e ) = ?u •
5430 ACCEPT BEEP VAL I DATE < D I GI T ) NULL ( O ) , T E
5440 IF TE< > STH+ STK+ I NT ( TD/ 1 0 ) THEN GOSUB 570 0 : GOT O 5420
5500 CALL DBLPRT < STR$ ( TE- 1 0 * I NT < TE/ 1 0 ) ) , " 0 B " , 1 4 , 1 6 )
5510 IF STL=O THEN CALL DBLPRT ( STR$( 1NT < TE/ 1 0 ) ) , " O B " , 1 2, 1 6)
5515 IF CH=2 OR STL=O THEN 5600
5520 CLS : LOCATE ( 1 9 , 1 ) : PR I NT " En f i n l e s " ; A$ ( 6 )
5530 PRINT STL ; " + " ; I NT <TE/ 1 0 ) ; " ( de r e t e n u e ) = ? " ;
5540 ACCEPT BEEP VAL I DATE( DI G I T )NULL ( O ) , T F
5550 IF TF < > STL+ INT < TE/1 0 ) THEN GOSUB 570 0 : G OT O 5520
5580 CALL DBLPRT < STR$(TF) , " O B" , 1 2 , 1 6 )
5600 CLS : LOCATE ( 1 9 , 1 ) : CALL COLOR( " O BG " )
5605 PRINT " TU AS TERM INE CETTE MULT I PL I CAT I ON " : CA L L C OLOR ( " O BC " ) : PR I NT
5610 NO=NO+ l
5620 IF N0=4 THEN 1 0 0 0 0
5630 PRINT : PRINT " Vo i c i u n e au t r e op e r a t i on . . . " : PAUSE 5
5650 CLS : GOTO 270
5700 ! *** ERREUR ADD I T I ON
5710 PRINT : PRINT UTLJ TE T ROMPES , 11 ; N$ ; 11 ! 11
5715 PRINT " REFLECHI S ET RECOMMENCE CETTE ADD I T I ON "
5720 PAUSE 5 : CLS : RETURN
10000 CALL H R OFF : CAL L DB L P RT ( 11 C ✓ EST TE RM I NE . 1 1,11 0 B 11 , 1 , 1 2 )
10010 CALL DBLPRT( "AU REVO I R , 11 &N$ , 11 0 b " , 1 , 1 5 )
10020 END
10030 CALL NORMAL : LOCATE ( 1 , 1 ) : RETURN 1 0 0 0 0
11600 SUB I N I T
11700 CALL POKE ( 50 850 , 1 62 , 5 , 4 5 , 1 62 , 1 36 , 4 5 , 1 0 ) : CALL EXE C (50850 )
11800 CALL POKE ( 50688 , 1 65 , 8 , 6 , 1 0 ) : CALL POKE ( 49 1 56 , 1 9 8 , 0 )
11900 SUBEND
12000 SUB DBLPRT ( Z$ , C$ ,X , Y )
12100 CALL COLOR ( C$ ) : CALL COLOR( " O LH " )
12200 K$= 11 11 : FOR 1 = 1 TO LEN ( Z$ )
12300 K$=K$&RPT$ ( SEG$ ( 2$ , l , 1 ) , 2 ) :NEXT
12400 LOCATE < Y ,X) : PR I NT K$
12500 LOCATE (Y+ 1 ,X ) : PR I NT K$
12600 CALL NORMAL : SUBEND
12700 SUB NORMAL
12800 CALL COLOR( " O BC " )
12900 SUBEND
13000 SUB CLR
13100 FOR 1=1 TO 22 : LOCATE < I , 1 ) : PR I NT RPT$ ( " " , 40 ) : N EXT
13200 SUBEND
