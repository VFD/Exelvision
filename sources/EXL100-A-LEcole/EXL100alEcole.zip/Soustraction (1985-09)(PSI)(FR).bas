100 ! ******** SOUSTRACT I ON *************
110 ! ****** VERSI ON EXL 1 0 0 ************
120 ! ***** D . N I ELSEN - 1 985 ***********
130 ! **********************************
140 ON B REAK ERROR
150 ON ERROR 750
160 CLS " BCC" : CALL HROFF : CALL INIT

170 NO=O : A$ ( 1 ) = " u n i t e 11 : A$ ( 2 ) = 11 d i z a i ne 11 : A$ ( 3)=" c en t a i ne" : Z Z$= 11 SOUST RACT I ON11
180 CALL DBLPRT < Z Z$ , " O b" , 8 , 1 2)
190 LOCATE ( 1 5 , 5 ) : PR INT " Qu e l e s t t on prenom ?" ;
200 ACCEPT BEEP VAL I DATE< ALPHA ) ,N$
210 PR I NT : PR I NT " Sou s t r ac t i ons avec des nombr es a UN , DEUX " ; " o u T RO I S c h i f f r e s ?"
220 CALL COLOR ( " O R " ) : PRINT"Indique ton choix < 1 , 2 ou 3 ) : Il j
230 ACCEPT BEEP VAU DATE( 11 1 23 11 )NULL< 1 ) SI Z E < 1 ) , CH
240 RANDOMIZE LEN(N$)*5
250 ! *** CHOIX DES CHIFFRES
260 CALL HRON < u C " , 1 4 , 1 ) : CALL INIT : CLS
270 AC , BC , A D , BD , AU , B U=O : ON CH GOTO 300 , 290 1 280
280 AC= INT RND ( 9 ) : BC= INTRND( 9 )
290 A D= I NT RN D ( 9 ) : BD= I NTRND ( 9 )
300 A U= I NT RND ( 9 ) : B U= I NT RND ( 9)
310 ! *** AFF I CHAGE DE L' OPERAT I ON
320 A= 1 0 0 *A C + 1 0 *AD+AU
330 8= 1 0 0 *BC+ 1 0 *BD+ B U
340 CALL CLR
350 CALL DBLPRT ( ST R$ ( A ) , u O B " , 24-CH*2 , 3 ) : CALL DBLPRT ( 11-11 &ST R$ ( 8 ) , " 0 B " , 20 -2*CH , 6)
360 CALL DBLPRT ( R PT$ ( CHR$ ( 4 ) , 2+ CH ) , " O B " , 20-CH*2 , 9 )
370 LOCATE ( 1 5 , 1 )
380 I F A < B T HEN 770
390 I F CH= l T H EN 480
400 LOCATE ( 1 5 , 1 ) : PR I NT " Par qu e l s c h i f f r e s c ommen c e stu t a a
410 PR I NT " s ou s t r- ac t i on " : PR I NT " Les un i t e s . . . . . . 1 ": PRINT " Le s d i z a i n e s . . . . 2 "
420 I F C H= 3 T HEN P R I NT " Le s c e n t a i n e s . . . 3 "
430 CALL COLOR < " O R " ) : PR I NT : PRINT "Ton c h o i x ( 1 , 2 o u 3 )
•. Il •' 440 ACCEPT BEEP VAL I DAT E C " 1 23 1
1 ) SI Z E( 1 )NULL C 1 ) , DEB
450 I F D E B= l T H EN 480
460 CALL COLOR C " O R B " ) : P R I NT 11 Tu t e t r omp e s " ; NS ; " , r e f le c h i s e n c or- e . "
470 PAUSE 5 : CL S : CALL NORMAL : GOT O 370
480 ! ***
490 N 1 =A U : N2= B U :X= 2 2
500 T$=A$ ( 1 ) : VS=A$ ( 2 ) : GOSUB 870

51 0 I F CH=! THEN 570
5 2 0 N 1 =AD : N2=BD : X=20 530 T$=A$ ( 2 ) :V$=A$( 3) : GOSUB 870
540 I F CH=2 THEN 570
550 N1=AC :N2=BC :X= 1 8
560 T$=A$ ( 3 ) : GOSUB 870
570 CLS : CALL DBLPRT ( " BRAVO 1
1 &N$ , 11 0 R 11 , 1 , 1 5 )
580 NO=NO+ l : PAUSE 3
590 I F N0 <4 THEN 270
600 GALL HROFF : GOTO 720
61 0 ! *** TABLE D✓ ADD I TI ON
620 CLS : LOCATE ( 1 5 , 1 )
630 GALL COLOR( 11 OBR" ) : PRINT "TU TE TROMPES , 11 ; N$
640 PRINT " RELI S LA TABLE D'ADD I T I ON " : PAUSE 4
650 CLS : CALL NORMAL
660 FOR 1=1 TO 1 0
670 PRINT N2 ; " + " ; I ; 11 = 11 ;N2+ I ,
680 NEXT I
690 GALL COLOR ( " O b " ) : PRINT : PR I NT "AS-TU TROUV E LA BONN
E REPONSE , " ;NS ; " ?"
700 PAUSE 1 0
71 0 CLS : CALL NORMAL : LOCAT E ( 1 5 , 1 ) : RETURN
720 CLS : CALL DBLPRT( " C ✓ EST TERM I NE . 1
1 , " 0 B " , 1 , 1 2 )
730 CALl DBLPRT< "AU REVO I R , 11 &N$ , 11 0 b 11 , 1 , 1 5 )
740 END
750 CALL HROFF : CALL NORMAL : RET URN 720
760 CALL HROFF : CALL NORMAL : LOCATE < 1 , 1 ) : RET URN 720
770 ! *** SOUSTRACTI ON I MPOSS I BLE
7 8 0 PR I NT I I Es t -ce q u e tu p eux f a i r e c e t t e 11 , 11 sou s t r a c t i
on , " ;NS
790 PRI NT : PRINT 11 1 pour ou i , 2 p our n on ? " ;
80 0 ACCEPT BEEP VAL I DATE( " 1 2 " ) SI Z E( 1 )NULL< 1 ) , I
81 0 I F 1=2 THEN 840
820 PR INT : PRINT "ATTENTI ON , " ;N$ ; 11 , r e garde 11 : PR I NT '' b i e n
l e s deu x nombr e s . "
830 PR INT " Ref l e ch i s en core , 1
1 : GOTO 780
840 PR INT "Tu as ra i son , " ;N$ ; 1
1 , n ou s " : PR I NT " a l l on s don
c f a i r e une au t r e "
850 PR INT " operat i on . " : PAUSE 5
860 GOTO 270
870 ! *** SOUSTRACTION PAR UNITES
880 CLS : IF RET= l THEN GOSUB 1100
890 PRINT " Que font " ;N1 ;TS ; : IF N1 ) 1 THEN PRINT " s " ;
900 PRINT "-" ;N2 ;TS ; : IF N2) 1 THEN PRINT " s " ;
910 PRINT " Si tu ne peux pas faire cette ","soustraction, tapes <N> "
920 ACCEPT BEEP VAL I DATE ("0123456789N") SIZE(2) NULL < " N ") , REP$
930 IF REP$="N" AND N1<N2 THEN 1000

940 IF REPS= "N"THEN 970
950 R=􀉸)A L <REPS)
960 IF R=N1-N2 THEN 980
970 GOSUB 620 : GOTO 890

980 CALL COLOR< "OBR" ):P RINT "C'EST EXACT ," ;NS:CALL DBLPRT(STR$ < R ) , " 0 b " , X , 1 2)
990 PA USE 5:RETURN
1000 !*** RETENUE
1010 CLS : PRINT " Il faut donc prendre une " ; V$ : PRINT " et l'ajouter aux ";N1 ;T$;
1020 IF N1 >1 THEN PRitH "s" ELSE PRINT
1030 PRINT "Cela fait" ;N1+10 ;TS; :IF N1 >1 THEN PRINT "s" ELSE PRINT
1040 RET=-1:P AUSE 5:CLS
1050 CA LL COLOR ( "Ob "):LOCAT E <2,X) :PRINT "1" : L OCAT E <B,X -2) : PR I NT " + 1 "
1060 CA LL NORMAL : LOCATE (15,1) : P RINT "Que font" ;N 1+10 ;"-" ;N2;" ?"
1070 INPUT R
1080 IF R= N1+10-N2 THEN 980
1090 GOSUB 620 : GOTO 1060
1100 !*** RETENUE PR ECEDENT E
1110 PRINT:PRINT "Nous avons ut il ise une ";T$
1120 PRINT "pou r effectuer la soustraction" :PRINT "precede nte ."
1130 PR INT '' L'operat ion a faire ma intenan t est donc :"
1140 PRINT N1 ; "-" ;N2+1 ;" et non ";N1 ; "-" ;N2
1150 N2= N2+ 1 :RET= O : RETURN
1160 SUB !NIT
1170 CALL POKE( 50 850 ,162 ,5,45,162,136,45,10) :CALL EX EC(50850 )
1180 CALL POKE( 5068 8, 165,B,6,10) :CALL POKE(491 5 6 ,198,0)
1190 SUBEND
1200 SUB DBLPRT(ZS,CS,X,Y)
1210 CALL COLOR( C$) :CALL COLOR( "OLH" )
1220 K$="" :FOR 1=1 TO LEN( 2$)
1230 KS= KS& R PT-$ ( SEG$( 2$ , I, 1) , 2) :N8(T
1240 LOCATE <Y ,X) :PRINT KS
1250 LOCATE (Y+l ,X) :PRINT KS
1260 CALL NORMA L :SUBEND
1270 SUB NORMA L
1280 CALL COLOR( " OBC" )
1290 SUBEND
1300 SUB CLR
1310 FOR 1=1 TO 22 : LOCATE <I ,1):PRINT RPTS( " ",40 ) :NEXT
1320 SUBEND

