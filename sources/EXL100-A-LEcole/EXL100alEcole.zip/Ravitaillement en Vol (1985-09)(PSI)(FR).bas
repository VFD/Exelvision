2 ! ***** RAV ITA I LLEMENT EN VOL ******
3 ! ******** VERS I ON EXL 1 0 0 *********
4 ! *** D , N I ELSEN - 1 985 *************
5 ! **********************************
7 CALL I N I T : CLS " BCC" : CALL COLOR ( " OBC" )
20 ON BREAK ERROR : ON ERROR 4 0 0 0
3 5 CA L L CHAR ( 48 , " 0 0 0 0 0 0 0 0 0 60F l E3C0 0 0 0 " )
40 CALL CHAR < 4 9 , " 0 0 0 0 1 F36FF7FO O O O O O O O " >
45 CALL CHAR ( S0 , " 7 8 F O F FAAFFFFF0780 0 0 0 " )
50 CALL CHAR ( S l , " 0 30 7 FFBEFCFCO O O O O O O O " >
55 CALL CHAR < S2 , " 3C l E O F 0 7 0 30 0 0 0 0 0 0 0 0 0 " )
60 GS < l > = • o •
65 GS < 2 > = " 1 23 "
70 GS < 3 ) = " 4 "

100 CL S : CALL DBLPRT ( " RAV I TAI LLEMENT " , " OB" , 6 1 1 0 )
110 CALL DBLPRT ( " EN VOL " , " O B " , 1 3 1 1 5 )
120 PAUSE 5
130 CLS : LOCATE ( 5 , 5 )
140 PRINT " RAV I TA I LLER Lt-l AV I 􀁙 EN VOL , C' EST LUI D􀁙NER D U CAR B U R􀃸T SANS 0;
142 PRINT " QU ' I L S O I T " ; : PR I NT " OBL I GE D ' ATTERR I R . "
150 PRINT " PO U R CELA , I L FAUT QUE L ' AV I 􀁙 RAVI TA I LLEUR ( e n r ou ge ) • ;
151 PRINT " SO I T A LA MEME ALT I TUDE QUE L ' AV I 􀁙 DE C􀃹SSE ( e n b l e u ) "
155 PAUSE 20
157 CLS : LOCAT E < 5 , 5 )
210 PRINT " L ' ALT I T UDE EST Co-lPR I SE ENTRE O ET 200 METRES"
220 PRINT "TU P I LOT E S L ' AV I 􀁙 RAV I TA I LEUR ET TU DOiS DCN'-IER T(t,I ALT I T U D E "
230 PRINT " Si ton altitude est trop elevee, ton avion < e n r pu ge ) monte au " ;
232 PRINT " dessus de " ; : PRINT " l ' av i on de c h a s s e •
240 PRINT " S i t o n a l t i t u d e e s t t r o p b a s s e , t on av ion ( e n r o u ge ) d e s c e n d • ;
242 PRINT " e n de ssou s de " ; : PR I NT " l ' av i on de c h as s e •
250 PRINT " T U D O I_S TROWER L ' ALT I TUDE EXACTE"
260 PRINT : PRINT " SI TU ES PRET TAPE SUR 'C' ET 'PRET'";
265 ACCEPT VA L I DAT E ( ° C " ) S I Z E ( l )NULL< " C " > , PS
270 IF PS < > ° C " TH EN 260
500 C=0
505 CLS : PRINT " QU E L L E A LT I T U D E PROPOSES-TU ?" ;
506 ACCEPT VALIDATE < D I GI T ) S l z'E ( 3 )NULL< O > , A
510 IF A ) 20 0 O R A < l THEN 5 0 0
520 IF A ) l O O T H EN B= I NT < RN D • <AJ 1 0'> > •8+ 1 ELSE B= I NT < RND• < AJ 1 0 ) > * 1 5+ 1
900 CALL H R ON ( " G " , 1 7 , 1 )
901 LOCAT E ( 1 , 1 > : FO R 1 = 1 T O 3
910 LOCATE ( 6+ 1 , 5 ) : CA L L C O L O R ( " l bC " > : PR I NT G$ ( 1 ) : CALL COLOR ( " O B C " >
930 NEXT I
950 LOCATE (18,1)
1000 !************ JEU **************
1005 IF A>B THEN Y=2
1010 IF A<B THEN Y=11

1015 IF A=B THEN Y=6
1030 FOR 1 = 1 TO 3
1040 LOCATE (Y+ I , 20 > : CALL COLOR( " 1 RC " > : PR I NT GS < I > : CALL COLOR< " O BC" )
1050 NEXT I
1090 I F A=B THEN 20 0 0
1100 C=C+ 1
1110 I F C > 1 0 THEN LOCATE < 22 , 1 ) : PR I NT " DEPECHE T O I , TUN'AS PLUS QUE" ; 1 5-C ;
1111 I F C) 1 0 THEN PR I NT " ALT I T UDES A PROPOS E R "
1115 I F C= 1 4 T H EN LOCATE ( 2 2 1 1 ) : PR I NT " C ' EST TA DERN I ERE C􀃺CE ,TU N ' AS PLUS " ;
1116 I F C= 1 4 THEN PRINT " QU ' l.NE ALT I TUDE A PROPOSER"
1120 IF C= 1 5 THEN 3 0 0 0
1130 I F C< 1 1 THEN 1 2 1 0
1140 PAUSE 5
1210 CLS : LOCATE ( 20 1 1 ) : PR I NT " CE N ' EST PAS LA B􀂕E A LTI TUDE . QUELLE " ;
1211 PRINT " NOWELLE ALT I TUDE PROPOSES-TU ? " ;
1215 ACCEPT VAL I DATE < D I G I T > S I Z E ( 3 ) NULL ( 0 ) 1 A
1220 GOTO 900
2000 ! ********* GAGNE **************
2005 LOCATE < 22 , 1 > : CLS : PR I NT " GAGNE , C ' EST LA B􀂕E ALTI T UDE , TU PEUX•
2010 PRINT " RAl.:,IITAI LLER L ' AV I CJ,1" : PR I NT "TU AS GAGNE EN "; C ; " REPCJ,ISES"
2030 GOTO 4 0 0 0
3000 ! ********* PERDU **************
3005 LOCATE < 22 , 1 ) : CLS : PR I NT " PERDU , C ' EST TROP TARD . L 'AV I CJ,I DE CAASSE N ' A " ;
3010 PRINT " PLUS DE CARBURANT "
4000 ! ********** F I N DU JEU *********
4001 PAUSE 1 0 : CALL HROFF
4010 PRINT " LNE AUTRE PART I E OIN " ;
4015 ACCEPT VAL I DATE( " CJ,l " ) S I Z E ( 1 )NULL < " C " ) , T$
4030 I F T$= " 0 "THEN 500
4035 CLS : END
10000 SUB INIT
10010 CALL POKE ( 50 850 1 1 62 , 5 , 4 5 , 1 62 , 1 36 , 45 , 1 0 ) : CALL EXE C <50850 )
10020 CALL POKE ( 50 688 1 1 65 1 8 , 6 , 1 0 ) : CALL POKE ( 4 9 1 5 6 1 1 98 1 0 )
10030 SUBEND
10040 SUB PLAY ( N O$ , L , D )
10050 FOR 1 = 1 TO L EN ( NO$ ) STEP 2
10060 K=POS < " DO . RE . H I . FA . SO . LA . S I . " , SEG$ ( N0$ 1 I , 2 > , 1 )
10070 P=VA L < SEG$ ( " 1 99 1 761 58 1 49 1 33 1 1 8 1 0 5 " , K , 3) )
10080 CALL POKE ( 258 1 P , D+ 1 28 ) : PAUSE U50
10090 NEXT : CALL POKE ( 259 , 0 ) : SUBEND
10100 SUB DBLPRT ( Z$ , C$ 1 X ,Y )
10105 CALL COLOR ( C$ )
10110 CALL COLOR < " O LH " )
10120 K$= " " : FOR 1 = 1 TO LEN ( Z$)
10130 K$=K$&RPTS < SEG$ ( 2$ , l , 1 ) , 2) :NEXT
10140 LOCATE < Y , X ) : PR I NT K$
10150 LOCAT E ( Y+ l , X ) : PR I NT K$
10160 CALL COLOR( " OBC " ) : SUBEND





