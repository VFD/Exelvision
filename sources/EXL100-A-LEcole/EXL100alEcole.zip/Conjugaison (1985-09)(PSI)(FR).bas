1 00 ! ********* CONJUGA I SON ************
1 1 0 ! ********* VERS I ON EXL 1 0 0 ********
1 20 ! ***** D .N I ELSEN - 1 985 ***********
1 30 ! **********************************
1 40 DIM V$ ( 40 ) , PR$ ( 6 ) , TERM$ ( 6 ) , TEMP$ ( 4 ) , PER$ ( 6 )
1 50 NB , L=O
1 60 CALL I N I T : RESTORE : CLS " BCC"
1 70 CALL DBLPRT ( " CONJUGA I SON" , " O R " , 7 , 1 2 )
1 80 LOCATE ( 1 5 , 5) : PRINT " Qu e l e s t t o n p r e n om ? " ;
1 90 ACCEPT BEEP VALI DATE <ALPHA) , N$
20 0 ! *** LECTURE DES DATAS
21 0 RANDOM I Z E LEN(N$)
220 READ lJ$ : IF W$= " * "THEN 250
230 L=L+ 1 : V$ ( L )=W$
240 GOTO 220
250 FOR I = l TO 6
260 READ PR$( ! ) , PER$( l )
270 NEXT I
280 FOR 1=1 TO 4
290 READ TEMP$( I )
300 NEXT l
3 1 0 ! *** T I RAGE AU SORT
320 W= INTRND ( 28)
330 P= INTRND ( 6)
340 I F P ) 6 THEN 330
350 T= INTRND ( 4 )
360 I F T)4 THEN 350
370 W$='-)$ ( 1,.J )
380 P$=PR$ ( P )
390 PE$=PER$( P)
400 TEM$=TEMP$ (T )
4 1 0 ! *** CONJUGAI SON
420 CLS : CALL DBLPRT ( W$ , " O b" , 5 , 5 )
430 LOCATE ( 8 , 1 ) : PRINT " Conj u gu e c e v e r be au " ; T EMS
440 PR INT " a l a " ; PE$ ; " . "
450 LOCATE < 1 5 , 5 ) : CALL NORMAL : L INPUT REP$ : CALL UPPER ( R
E P$ )
460 ! *** TEST REPONSE
470 I F SEG$(W$ , LEN (W$) -1 , 2) = " I R " THEN 530
480 ON T GOSUB 490 , 50 0 , 5 1 0 , 520 : GOTO 580
490 RESTORE 1 1 30 : RETURN
500 RESTORE 1 1 40 : RETURN
5 1 0 RESTORE 1 1 50 : RETURN
5􀜈0 RESTORE 1 1 60 : RET URN
530 ON T GOSUB 540 , 550 , 560 , 570 : GOTO 580
540 RESTORE 1 1 70 : RET URN
550 RESTORE 1 1 80 : RETURN
560 RESTORE 1 20 0 : RETURN
570 RESTORE 1 2 1 0 : RETURN


580 FOR 1 = 1 T O 6 : READ TERM$ ( l ) :NEXT I
590 L=L EN ( W$ )
60 0 RAD$=SEG$ ( W$ , 1 , L-2)
6 1 0 I F REP$=P$& " " &RAD$&TERM$ ( P )THEN 800
620 ! *** RE PONSE FAUSSE

630 PR I NT : CA L L COLOR ( " O R811 ) : PRINT 11 Tu t e t r omp e s , " ;N$ :
CAL L NORMAL
640 PAUSE 3
650 FOR 1 = 1 4 TO 2 2 : LOCAT E < I , 1 > : PRINT RPT$( " " , 39 ) ; :NE
XT
660 LOCAT E < 1 4 , 5 ) : PR INT " Vo i c i un exemp l e de c on j u ga i s
on "
670 PR I NT " d ' u n v e r be semb l ab l e au " ; TEMS
680 I F SEG$ ( W$ , LEN ( W$ ) - 1 , 2 )= 11 I R11 THEN EX$= 11 F I N11 ELSE EX
$= " C HANT "
690 CALL COLOR( " O b " )
7 0 0 FOR 1 = 1 T O 6
7 1 0 LOCATE ( 1 5+ 1 , 1 0 )
720 PR I NT PR$ ( I ) ; " 11
; EX$ ; T ERM$ ( I )
730 NEXT I
740 CALL NORMAL : PR I NT 11 As- t u t r ou ve ?" ;
750 PAUSE 1 0
760 FOR 1 = 1 3 T O 22 : LOCATE C J , 1 ) : PRINT RPT$ ( 11 " , 39 ) ; :NE
XT
770 CAL L NORMA L : LOCAT E ( 1 3 , 1 ) : PR I NT I I Que 1 1 e e s t t a n ou
v e 1 1 e r e p on se ? 11
780 L I NPUT REPS
790 GOTO 6 1 0
800 ! * ** RE PONSE EXA CT E
8 1 0 PR I NT : CALL COLOR ( 11 0 G8 11
) 820 PR I NT " C ' E ST EXACT " ; NS : CALL NORMAL : PRINT
830 NB=NB+ l
840 I F NB= 9 T H EN 880
850 PR I NT " Vo i c i un au t r e v e r be . 1
1
860 PAUSE 5
870 GOTO 3 1 0
880 ! *** F I N D U J E U
890 PAUSE 5 : CL S
9 0 0 CAL L D B LPRT C 11 C ' E ST TERM I NE , 1
1 , " 0 R u , 5 , 1 5 ) : CALL DBLPR
T ( N$ , 11 0 b 1
1
, 5 , 1 7 )
9 1 0 CA LL DBLPRT ( 11 AU REVO I R ! 11 , 11 0W 11 , 5 , 1 9 )
920 DATA CHAHUT E R , P LEURER , JOUER
930 DATA COP I E R , CREER , FOURN I R
940 DATA F L E U R I R , SOLDER , FR EM I R
950 DATA F R I S E R , F L E CH I R , F ROTTER
960 DATA LOUER , NO I RC I R , PA L I R
970 DATA PARFUMER , P E DA L E R ,M ESURER
980 DATA RAC COURC I R , NOURR I R , REFUSER
990 DATA RONFLER , RE UN I R , REUSS I R

1000 DATA SERRER ,P􀐇I R,BONDIR
1010 DATA VIEI L LIR,TRA HI R,CONVERTIR
1020 DATA *
1030 DATA JE , 1 ere personne du ·si ngu 1 i er
1040 DATA TU , 2eme personne du sing ul ier
1050 DATA IL,3eme person ne du singul ier
1060 DATA NOUS ,1e re pe rsonne du plur iel
1070 DATA VOUS , 2eme personne du pluriel
1080 DATA ILS,3eme personne du pluriel
1090 DATA Prese nt de 1 ✓ indicat if
1100 DATA Imp arfa it de 1 ✓ indicat if
1110 DATA Fu t􀜉r simpl e
112 0 DATA Passe simple
113 0 DATA E,ES,E,ONS ,EZ ,ENT
1140 DATA AIS ,AI S ,AIT ,IONS ,IE Z ,AI ENT
1150 DATA ERAI ,ERA S ,ERA,ERONS ,EREZ , ERONT
116 0 DATA AI ,AS ,A ,AMES ,ATES , ERENT
1170 DATA IS,IS,IT,ISSONS ,ISSEZ ,ISSENT
118 0 DATA ISSA I S,ISSAIS ,IS SA IT ,ISSI ONS
1190 DATA ISSI E Z ,IS SA I ENT
1200 DATA IRAI ,IRA S,IRA,IRON S,IR E Z,IRONT
1 21 0 DA TA I S , I S , 1T , I MES , 1T ES , I RENT
1220 SUB !NIT
1230 CA LL POKE< 50 850 , 162, 5. , 45 ,162 ,136, 45 , 10) : CALL EX EC(
50 850 )
1240 CA LL POKE (5068 8,165,B,6,10) :CALL POKE(491 56 ,19 8,0)
1250 SUBEND
1260 SUB PLAY <NO$ ,l,D)
1270 FOR 1=1 TO LEN(N0$ ) ST EP 2
1280 K= POS( a DO ,RE.MI .FA,SO.LA,SI ." ,SEG$(N0 $,l ,2),1)
1290 P=VAL (SEG$( "19 91 761 581 491331 18105" ,K,3))
1300 CA LL POKE(25 8,P,D+128) :PAUSE L/ 50
1310 NEXT :CALL POKE(2 5 9,0) : SUBEND
1320 SUB DBLPRT( 2$,C$,X,Y)
1330 CA LL COLOR(C$) :CALL COLOR( "OLH" )
1340 K$= 11 11 :FOR 1=1 TO LEN(2$)
1350 K$= K$&RPT$ (SEG$(2$, l,1) ,2) :NEXT
1360 LOCATE <Y ,X> :PRINT K$
1370 LOCATE (Y+l ,X) :PRINT K$
1380 CA LL NORMAL : SUBEND
1390 SUB NORMAL
1400 CA LL COLOR< "OBC" )
1410 SUBEND
1420 SUB UPPER( 2$ )
1430 K$= 11 ": FOR K= l TO LEN( 2$)
1440 S= ASC< SEG$(2$,K,1)) :IF 5)90 THEN S=S-32
1450 K$= K$& CHR$( S) :NEXT :2$= K$
1460 SUBEND


