100 ! *********** ADDITION *************
110 ! ********* VERS ! 􀜊 EXL100 ********
120 ! ***** D.NIELSEN - 1985 ***********
130 ! **********************************
140 ON BREAK ERROR
150 ON ERROR 1 1 40
160 CALL HROFF : CALL INIT : CLS II BCC"
170 NO=O
180 CALL DBLPRT( "ADD I T I ON " , " Ob " , 1 2 , 1 2 )
190 LO CAT E ( 1 5 , 5 ) : PR I NT II Que 1 e s t t on p r e n om ? 11 ;
200 ACCEPT BEEP VAL I DATE<ALPHA ) ,N$
210 PRINT : PRINT "Add i t i on s avec des n ombr e s a UN , DEUX";" ou TROI S ch i f f r e s ?"
220 CALL COLOR( " O R" ) : PRINT " I n d i q u e t on c h o i x C l , 2 ou 3 ) : · Il ;
230 ACCEPT BEEP VAL I DATE< 11 1 23 " )NULL ( 1 ) S I Z E ( 1 ) , C H
240 RANDOM I Z E LEN (N$) *5
250 CALL HRONC " C " , 1 2 , 1 ) : CALL I N I T
260 ! *** CHOIX DES CHIFFRES
270 IF N0=4 THEN CALL HROFF : GOTO 1 1 1 0
280 AC , BC , AD , BD , AU , BU=O : ON CH GOTO 3 1 0 , 30 0 , 290
290 AC=I NTRND ( 9 ) : BC=INTRND ( 9 )
300 AD=I NTRND ( 9 ) : 8D=INTRND ( 9)
310 AU=I NTRND ( 9 ) : 8U=INTRND( 9)
320 ! *** AFFICHAGE DE L'OPERATION
330 A= 1 0 0*AC+ 1 0 *AD+AU
340 B= 1 0 0 *BC+ 1 0 *BD+BU
350 CALL CLR
360 CALL DBLPRT C STR1( A) , " O B" , 24-CH*2 , 3 ) : CALL DBLPRT C u +11 & ST R$ ( 8 ) , 11 0 B 11 , 2 0 -2 * CH , 6)
370 CALL DBLPRT ( RPT$C CHR$ ( 4 ) , 2+ CH ) , " O B " , 20 -CH*2 , 8 )
380 RED , RC=O
390 LOCATE ( 1 5 , 1 )
400 I F CH=l THEN 490
410 LOCATE ( 1 5 , 1 ) : PRINT " Par qu e l s c h i f f r e s c omme n c e stuton u 
420 PR I NT " ad d i t i on : 11 : PR I NT II Les u n i t e s . . . . . . 1 " : PRINT " Le s d i z a i n e s . . . . 2 "
430 I F CH=3 THEN PRINT " Les c e n t a i n e s . . . 3 "
440 CALL COLOR ( " OR " ) : PRINT : PRI NT " Ton c h o i x ( 1 , 2 o u 3 ).t Il • , 450 ACCEPT BEEP VALI DATE < " 1 23" ) SI Z E( 1 ) NULL ( 1 ) , DEB
460 I F DEB= l THEN 490
470 CALL COLOR < " O RB" ) : PRINT "Tu te t r omp e s " ; N$ ; " , r e f 1e c h i s e n c o r e . " 1
480 PAUSE 5 : CLS : CALL NORMAL : GOTO 390
490 ! *** ADDI T I ON DES UN ITES
500 CLS : PRINT " Qu e f on t " ;AU ; " u n i te ( s ) " : PR I NT TAB ( 9 ) ; " +" ; BU ; " u n i t e s ? "

510 INPUT RU
520 IF RU=AU+BU THEN 550
530 T= AU : GOSUB 1000
540 GOTO 490

550 IF RU( 10 THEN CA LL DBLPRT<STR$(RU> ,"O b" ,22, 10) :GOTO 650
560 IF RU>9 AND CH=1 THEN CALL DBLPRTC "l"&ST Rt(RU -10) 1 uob" ,20,10) :GOT O 650
570 CA LL coLOR< "OGB" >: PR INT "c✓ EST EXA CT ," ;N$: CALL NORMAL
580 PRINT "Cela fait 1 dizaine, plus" ;RU-10;"unites"
590 PR INT "Il faut donc ecrire" ;RU- lO ;"dans la"
600 PR INT "colonne des unites ,et 1 au dessus de " ,"la colonne des dizaines ."
610 PAUSE 7
620 CA LL DBLPRTCST R$(RU-1 0) , "0b" ,22,10)
630 CA LL COLORC "Ob" ) :LOCAT E <1 ,20) :PRINT "+1"
640 PA USE 7
650 ! *** ADD ITION DES DI ZA INES
660 IF CH=1 THEN 950
670 CLS :CALL NORMAL :LOCAT E (15,1)
680 PR INT "Que font" ;AD;"dizaine(s) +" :PRINT TA8 (9) ;BD;"dizaine(s)"
690 RED=O :IF RU)9 THEN PR INT "plu s 1 dizaine de re tenue" :RED=1
700 INPUT RD
710 IF RD= AD+BD+RED THEN 740
720 T=A D :GOSUB 1000
730 GOTO 650
740 IF RD( 10 THEN CA LL DBLPRT<STR$<RD) ,"O b" ,20,10) :GOTO 840
750 IF RD)9 AN D CH=2 THEN CALL DBLPRT( "1"&ST R$(RD -1 0) ,11 Ob" , 18, 10) : GOTO 840
760 CA LL COLORC "OGB" ):P RINT "C✓ EST EXACT ," ;N$:CALL NORMAL
770 PRINT "Cela fai t 1 centaine, plus" ;RD- 10;"d izaine(s ) Il
780 PRINT "11 faut donc ecr ire" ;RD-10;"dans la"
790 PR INT "col o nne des di z aines ,et 1 au dessus de " ,"la colonne des centaines ."
800 PAUSE 7
810 CAL L DB L P RT ( ST R$ < RD-1 0 ) , " 0 b " , 2 0 , 1 0 )
820 CA LL COLOR ( "Ob "):LOCAT E (1 ,18) :PRINT "+111
830 PA USE 7
840 !*** ADDITION DES CENTA INES
850 IF CH=2 THEN 950
860 CA LL NORMAL :LOCAT E (15,1) :CLS
870 PR INT "Que font" ;AC;"centai ne(s) +" :PRINT TA 8(9) ;BC; "centaine(s)"

880 RC=O : I F R0>9 THEN PRINT 0 p l u s 1 c e n t a i n e de r e t e n ue • : RC=1
890 INPUT CC
900 I F CC=AC+BC+RC THEN 930
910 T=AC : GOSUB 1 0 0 0
920 GOTO 840
930 I F CC< 1 0 THEN CALL DBLPRT < STR$ ( CC ) , u 0 b " , 1 8 , 1 0 ) : GOT0 950
940 CALL OBLPRT( " 1 "&STR$ ( CC- 1 0 ) , " O b " , 1 6 , 1 0 )
950 ! *** BRAVO
960 CLS : CALL OBLPRT( 0 BRAVO u&N$ , 1
1 0 811 , 1 , 1 5)
970 PRINT : PRINT : PRINT uvo i c i ma i n te n an t u n e au t r e o p e ra t i on a
980 NO=N0+ 1 : PAUSE 7
990 G_OTO 270
1000 ! *** TABLE D'ADDITION
1010 CLS : LOCATE ( 1 3 , 1 )
1020 CALL COLOR( u O BR" ) : PRINT "TU TE TROMP E S , 11 ; N$
1030 PRINT "RELIS LA TABLE D'ADDITION" : PAUSE 4
1040 CLS : CALL NORMAL
1050 FOR 1=1 TO 1 0
1060 PRlNT T ; 11 + " ; l ; 11 =11 ;T+ I ,
1070 NEXT l
1080 CALL COLOR( " O b" ) : PR l NT : PRlNT "AS-T U T ROUV E LA B ONNE REPONSE , " ;N$ ; " ?"
1090 PAUSE 1 0
1100 CALL NORMAL : LOCATE ( 1 5 , 1 ) : RETURN
1110 CLS : CALL DBLPRT( " C ' EST TERM I NE . " , " O B " , 1 , 1 2 )
1120 CALL DBLPRT( "AU REVO l R , 11 &N$ , 110 b " , 1 , 1 5 )
1130 END
1140 CALL HROFF : CALL NORMAL : LOCATE ( 1 , 1 ) : RETU RN 1 1 1 0
1150 SUB l N IT
1160 CALL POKE ( 50 850 , 1 62 , 5 , 45 , 1 62 , 1 36 , 45 , 1 0 ) : CALL EXE C (50 850 )
1170 CALL POKE ( 50 688 , 1 65 , 8 , 6 , 1 0 ) : CALL POKE ( 49 1 5 6 , 1 98 , 0 )
1180 SUBEND
1190 SUB DBLPRT( Z$ , C$ ,X ,Y)
1200 CALL COLOR ( C$ ) : CALL COLOR( " O LH" )
1210 K$= 11 11 : FOR 1 = 1 TO LEN ( 2$ )
1220 K$=KS&RPT$ ( SEGS ( 2$ , l , 1 ) , 2 ) :NEXT
1230 LOCATE (Y ,X) : PR I NT K$
1240 LOCATE (Y+ l , X ) : PR I NT K$
1250 CALL NORMAL : SUBEND
1260 SUB NORMAL
1270 CALL COLOR < " O BC " )
1280 SUBEND
1290 SUB CLR
1300 FOR 1=1 TO 22 : LOCAT E ( l, 1): PRINT RPT$ ( 11 11, 40 ) : NEXT
1310 SUBEND




